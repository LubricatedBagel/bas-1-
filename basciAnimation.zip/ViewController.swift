//
//  ViewController.swift
//  basciAnimation
//
//  Created by Shamsa Mohamed on 3/15/23.
//

import UIKit

class ViewController: UIViewController {

    var myView: UIView!
    var mySecondView: UIView!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        let frame = CGRect(origin: CGPoint(x: 100, y: 100), size: CGSize(width: 25, height: 25))
        myView = UIView(frame: frame)
        myView.backgroundColor = UIColor(red: 100/255, green: 25/255, blue: 95/255, alpha: 1)
        view.addSubview(myView)
        let frameTwo = CGRect(origin: CGPoint(x: view.center.x, y: view.center.y), size: CGSize(width: 25, height: 25))
        mySecondView = UIView(frame: frame)
        mySecondView.backgroundColor = UIColor(red: 100/255, green: 25/55, blue: 95/255, alpha: 1)
    }
    @IBAction func goNextView(_ sender: UIButton) {
        
    }
    
    @IBAction func Animate(_ sender: UIButton) {
        let animation = CABasicAnimation(keyPath: "postion")
        animation.fromValue = CGPoint(x: 200, y: 100)
        animation.toValue = view.bounds.size.height
        animation.duration = 0.5
        animation.beginTime = CACurrentMediaTime() + 0.3
        animation.repeatCount = 3
        animation.autoreverses = true
        myView.layer.add(animation, forKey: nil)
    }
    
}

